public class Driver {
	public static void main(String args[]){
		ChooseInputUI ui = new ChooseInputUI();
        HTTPHandler handler = new HTTPHandler();
	}
}

