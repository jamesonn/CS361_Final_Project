import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Driver {
	public static void main(String args[]){
		ChooseInputUI ui = new ChooseInputUI();
	}
}

